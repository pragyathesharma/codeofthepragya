package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.MoveByAction;
import com.badlogic.gdx.scenes.scene2d.actions.MoveToAction;
import com.badlogic.gdx.scenes.scene2d.actions.ScaleByAction;
import com.badlogic.gdx.scenes.scene2d.actions.SequenceAction;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

import sun.rmi.runtime.Log;


/**
 * Created by 008400 on 5/4/2017.
 */

public class CoinActor extends Actor {

    TextureAtlas textureAtlas;
    Animation animation;
    TextureRegion textureRegion;
    Sprite sprite;
    float timeForStill = 0;
    boolean isDragging = false;
    int pointValue;
    Sound scoreSound, downSound, levelSound;


    public CoinActor(int type){
        if(type == 0) {
            pointValue = -20;
            textureAtlas = new TextureAtlas(Gdx.files.internal("CoinSprites3/CoinSprites3Atlas.atlas"));
        }
        else if(type >=1 && type<=4){
            pointValue = 5;
            textureAtlas = new TextureAtlas(Gdx.files.internal("CoinSprites2/CoinSprites2Atlas.atlas"));
        }
        else{
            pointValue = 1;
            textureAtlas = new TextureAtlas(Gdx.files.internal("CoinSprites/CoinAtlas.atlas"));
        }
        animation = new Animation<TextureRegion>(1/5f,textureAtlas.getRegions());
        textureRegion = (TextureRegion) animation.getKeyFrame(0,true);
        sprite = new Sprite(new Texture("11.png"));
        sprite.setSize(150,150);
        scoreSound  = Gdx.audio.newSound(Gdx.files.internal("coin.wav"));
        downSound  = Gdx.audio.newSound(Gdx.files.internal("fall.wav"));
        levelSound = Gdx.audio.newSound(Gdx.files.internal("level.wav"));
        setBounds(getX(),getY(),sprite.getWidth(),sprite.getHeight());
        setTouchable(Touchable.enabled);
        addListener(new InputListener(){
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                if (event.getTarget() instanceof CoinActor) {
                    if(!isDragging) {
                        MoveByAction moveUp = new MoveByAction();
                        moveUp.setAmount(0, 30f);
                        moveUp.setDuration(.2f);

                        MoveByAction moveDown = new MoveByAction();
                        moveDown.setAmount(0, -30f);
                        moveDown.setDuration(.2f);

                        SequenceAction sequence = new SequenceAction();
                        sequence.addAction(moveUp);
                        sequence.addAction(moveDown);
                        addAction(sequence);
                    }


                }
                return true;
            }

            @Override
            public void touchDragged(InputEvent event, float x, float y, int pointer) {
              //  super.touchDragged(event, x, y, pointer);
                setPosition(getX()+x+10, getY()+y+10);
                if(MyGdxGame.bounds.contains(getX()+x+10, getY()+y+10)) {
                    remove();
                    if(pointValue>0) {
                        for(int i = 0; i < pointValue; i++) {
                            MyGdxGame.score++;
                            if(MyGdxGame.score%100 == 0 && MyGdxGame.score >0)
                                levelSound.play(0.5f);
                        }
                        scoreSound.play(0.5f);
                    }
                    else
                    {
                        for(int i = 0; i < (pointValue*-1); i++)
                            MyGdxGame.score--;
                        downSound.play();
                    }
                }
                isDragging = true;
            }

            @Override
            public void touchUp(InputEvent event, float x, float y, int pointer, int button) {
                super.touchUp(event, x, y, pointer, button);
                isDragging = false;
            }
        });

    }

    @Override
    public void act(float delta) {
        super.act(delta);
        if(MyGdxGame.bounds.contains(getX(), getY())) {
            remove();

            if(pointValue>0) {
                for(int i = 0; i < pointValue; i++) {
                    MyGdxGame.score++;
                    if(MyGdxGame.score%100 == 0 && MyGdxGame.score >0)
                        levelSound.play(0.5f);
                }
                scoreSound.play(0.5f);
            }
            else
            {
                for(int i = 0; i < (pointValue*-1); i++)
                    MyGdxGame.score--;
                downSound.play();
            }
        }
        if (getX() <1620)
            setX(getX()+5);
        else
            remove();


    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        timeForStill += Gdx.graphics.getDeltaTime();
        textureRegion = (TextureRegion)animation.getKeyFrame(timeForStill,true);
        sprite.setRegion(textureRegion);
        sprite.draw(batch);
    }

    @Override
    protected void positionChanged() {
        sprite.setPosition(getX(),getY());
        super.positionChanged();
    }






}
