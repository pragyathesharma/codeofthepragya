package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.actions.MoveByAction;
import com.badlogic.gdx.scenes.scene2d.actions.MoveToAction;
import com.badlogic.gdx.scenes.scene2d.actions.ScaleByAction;
import com.badlogic.gdx.scenes.scene2d.actions.SequenceAction;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;



/**
 * Created by 008400 on 5/4/2017.
 */

public class Player extends Actor {


    TextureAtlas textureAtlasMove, textureAtlasJump;
    Animation<TextureRegion> moveAnimation, jumpAnimation;
    TextureRegion textureRegionMove, textureRegionJump;
    Sprite sprite;
    Sound jumpSound;
    float timeForJump = 0.0f;
    float timeForMove = 0.0f;
    boolean jump = false;
    boolean isDragging;
    boolean forceBounds = false;

    public Player(){
        textureAtlasMove = new TextureAtlas(Gdx.files.internal("RunSprites/RunAtlas.atlas"));
        textureAtlasJump = new TextureAtlas(Gdx.files.internal("JumpSprites/JumpAtlas.atlas"));
        moveAnimation = new Animation<TextureRegion>(1/20f,textureAtlasMove.getRegions());
        jumpAnimation = new Animation<TextureRegion>(1/20f,textureAtlasJump.getRegions());
        textureRegionMove = moveAnimation.getKeyFrame(0,true);
        textureRegionJump = jumpAnimation.getKeyFrame(0, false);
        sprite = new Sprite(new Texture("11.png"));
        sprite.setSize(200, 200);
        jumpSound = Gdx.audio.newSound(Gdx.files.internal("jump.mp3"));
        isDragging = false;
        setBounds(getX(),getY(),sprite.getWidth()+20,sprite.getHeight()+20);
        setTouchable(Touchable.enabled);
        addListener(new InputListener(){
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                    jump= !jump;
                    if(!isDragging && jump && MyGdxGame.jumps>0) {
                        jumpSound.play();
                        MoveByAction moveUp = new MoveByAction();
                        moveUp.setAmount(0, 500f);
                        moveUp.setDuration(.2f);

                        MoveByAction moveDown = new MoveByAction();
                        moveDown.setAmount(0, -500f);
                        moveDown.setDuration(.2f);

                        SequenceAction sequence = new SequenceAction();
                        sequence.addAction(moveUp);
                        sequence.addAction(moveDown);
                        addAction(sequence);

                        MyGdxGame.jumps--;

                    }
                return true;
            }

            @Override
            public void touchUp(InputEvent event, float x, float y, int pointer, int button) {
                super.touchUp(event, x, y, pointer, button);
               isDragging = false;
               forceBounds = false;
                setBounds(getX(),getY(),sprite.getWidth()+20,sprite.getHeight()+20);


            }

            @Override
            public void touchDragged(InputEvent event, float x, float y, int pointer) {
                isDragging = true;
                forceBounds = true;
                setPosition(getX()+x+10, getY());
                setColor(sprite.getColor().r, sprite.getColor().g, sprite.getColor().b, .2f);

            }
        });
    }

    @Override
    public void act(float delta) {
        super.act(delta);
        if (!jump && getX() <1550)
           setX(getX()+1);

        if(getX() >= 1550)
            setX(1550);

    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        timeForJump += Gdx.graphics.getDeltaTime();
        timeForMove += Gdx.graphics.getDeltaTime();
        if(timeForJump >=.48)
            jump = false;
        if (jump && timeForJump < .48 && MyGdxGame.jumps>0) {
            textureRegionJump = jumpAnimation.getKeyFrame(timeForJump,false);
            sprite.setRegion(textureRegionJump);
            sprite.draw(batch);
            timeForMove=0;
        }else{
            textureRegionMove = moveAnimation.getKeyFrame(timeForMove,true);
            sprite.setRegion(textureRegionMove);
            sprite.draw(batch);
            timeForJump=0;
        }
       // timeForStill += Gdx.graphics.getDeltaTime();

    }

    @Override
    protected void positionChanged() {
        sprite.setPosition(getX(),getY());
        super.positionChanged();
    }


    public Rectangle getPlayerRectangle(){
        if(forceBounds)
            return new Rectangle(0, 0, 0, 0);
        else return sprite.getBoundingRectangle();
    }



}
