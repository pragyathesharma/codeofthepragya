package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.input.GestureDetector;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;

import java.util.ArrayList;

public class MyGdxGame extends ApplicationAdapter {
	SpriteBatch batch;
    Stage stage;
    Player player;
    BitmapFont font;
    float jumpReload = 0;
    public static int score=0;
    public static int jumps=5;
    public static Rectangle bounds;

	@Override
	public void create () {
		batch = new SpriteBatch();
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);
        player = new Player();
        stage.addActor(player);
        bounds = player.getPlayerRectangle();
        font = new BitmapFont(Gdx.files.internal("bahnschrift.fnt"),false);
        font.setColor(Color.CORAL);

	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(0.988f, 1, 0.898f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        jumpReload+= Gdx.graphics.getDeltaTime();
        if((int)(jumpReload)%10 ==0 && jumpReload>0)
        {
            if(jumps<5) {
                jumps++;
                jumpReload++;
            }

        }

		if(stage.getActors().size<15)
            addCoin((int)(Math.random()*10));
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
        bounds = player.getPlayerRectangle();
        batch.begin();
        font.draw(batch, "Score: "+score, 20, 1050);
        font.draw(batch, "Jumps: "+jumps, 20, 990);

        batch.end();



	}

	@Override
	public void dispose () {
		batch.dispose();
		font.dispose();
        stage.dispose();
	}

	public void addCoin(int type)
    {
        CoinActor coin = new CoinActor(type);
        coin.setPosition((float) (Math.random() * 1500), (float) ((Math.random() * 800)+200));
        stage.addActor(coin);
    }


}